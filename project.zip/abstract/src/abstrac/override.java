package abstrac;

public @interface override {

}
