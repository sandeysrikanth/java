package abstrac;

public class squaare {
	public static void main(String[] args) {
		Rectangle s1 = new Square();
		System.out.println(s1.getArea());
		System.out.println(s1.getPerimeter());
	}
}

class Square extends Rectangle {

	public Square() {
		super();
		
	}

	public Square(double side) {
		super(side, side);
		
	}

	public Square(double side, String color, boolean filled) {
		super(side, side, color, filled);
	
	}

	public double getSide() {
		return super.getWidth();
	}

	public void setSide(double side) {
		super.setLength(side);
		super.setWidth(side);
	}

	@override
	public double getArea() {
		return getSide() * getSide();
	}

	@override
	public double getPerimeter() {
		return 4 * getSide();
	}

	@override
	public String toString() {
		return "A Square with side = " + getSide() + ", which is a subclass of " + super.toString();
	}
}