package abstrac;
public class abstractdemo{
	public static void main(String[] args) {
		Shape s1 =new circle();
		System.out.println(s1.getArea());
		}
}

abstract class Shape{
	protected String color;
	protected boolean filled;
	public Shape(){
		
		 String color="green";
		boolean filled=true;
	}
	public Shape (String color,boolean filled){
		this.color=color;
		this.filled=filled;
		}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public boolean isFilled() {
		return filled;
	}
	public void setFilled(boolean filled) {
		this.filled = filled;
	}
	abstract double getArea();
	abstract double getPerimeter();
	public String toString()
	   {
	       String isNot = "";
	       if(isFilled() == false)
	       {
	           isNot = "not ";
	        }
	           return "A Shape with color of " + color + " and is " + isNot + " filled. ";
	        }
	
	   }
class circle extends Shape{
	public double radius;
	public circle(){
		radius =1.0d;
		
	}
	public circle(double radius){
		this.radius=radius;
		
	}
	public circle(double radius,String color, boolean filled){
		
		super(color,filled);
		this.radius=radius;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	@override
	public double getArea(){
		return radius*radius*Math.PI;
		
	}
	@override
	public double getPerimeter(){
		return 2*Math.PI*radius;
		
	}
	@override
	 public String toString()
	   {
	      return "A Circle with radius = " + radius + ", which is a subclass of " + super.toString();
	   }
	}


	
	
	
	


